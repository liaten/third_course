import json

with open('bayes.json') as file:
    stock = json.load(file)
    result = ""
    for massiv in stock[0]['x1'][0]['name']:
        result+=massiv
    print(result)