import json

with open('bayes.json') as file:
    stock = json.load(file)
    result = ""
    for massiv in stock['x1']:
        result+=massiv+'\n'
    print(result)